import { useState } from 'react';

export default () => {
  const [reviewSolutionID, setReviewSolutionID] = useState(-1);
  // const set = (lists) =>{
  //   setLabels(lists);
  // }

  return { reviewSolutionID, setReviewSolutionID };
};
