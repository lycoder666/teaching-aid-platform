import { Tabs } from 'antd';
import ProblemDescription from '@/pages/course/components/ProblemDescription/index';
import { useModel } from 'umi';
const { TabPane } = Tabs;
import Solutions from '../../solution';

const ProblemDetails: React.FC = () => {
  const { currentProblemID, setCurrentProblemID } = useModel('CurrentProblemID');

  return (
    <Tabs defaultActiveKey="1" size="middle">
      <TabPane tab="Problem" key="1">
        <ProblemDescription problemId={currentProblemID} />
      </TabPane>
      <TabPane tab="Solution" key="2">
        <Solutions problemId={currentProblemID} />
      </TabPane>
    </Tabs>
  );
};

export default ProblemDetails;
