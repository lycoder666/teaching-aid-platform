export default {
  'component.tagSelect.expand': 'বিস্তৃত',
  'component.tagSelect.collapse': 'সঙ্কুচিত',
  'component.tagSelect.all': 'সব',
};
