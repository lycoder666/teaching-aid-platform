// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from '/Users/liyao/Desktop/Life/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@ant-design/pro-layout/es/PageLoading';

export function getRoutes() {
  const routes = [
  {
    "path": "/umi/plugin/openapi",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-openapi__openapi' */'/Users/liyao/Desktop/Life/src/.umi/plugin-openapi/openapi.tsx'), loading: LoadingComponent})
  },
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-layout__Layout' */'/Users/liyao/Desktop/Life/src/.umi/plugin-layout/Layout.tsx'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/~demos/:uuid",
        "layout": false,
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent})],
        "component": ((props) => dynamic({
          loader: async () => {
            const React = await import('react');
            const { default: getDemoRenderArgs } = await import(/* webpackChunkName: 'dumi_demos' */ '/Users/liyao/Desktop/Life/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
            const { default: Previewer } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi-theme-default/es/builtins/Previewer.js');
            const { usePrefersColor, context } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi/theme');

            return props => {
              
      const { demos } = React.useContext(context);
      const [renderArgs, setRenderArgs] = React.useState([]);

      // update render args when props changed
      React.useLayoutEffect(() => {
        setRenderArgs(getDemoRenderArgs(props, demos));
      }, [props.match.params.uuid, props.location.query.wrapper, props.location.query.capture]);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
            }
          },
          loading: () => null,
        }))()
      },
      {
        "path": "/_demos/:uuid",
        "redirect": "/~demos/:uuid"
      },
      {
        "__dumiRoot": true,
        "layout": false,
        "path": "/~docs",
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent}), dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'/Users/liyao/Desktop/Life/node_modules/dumi-theme-default/es/layout.js'), loading: LoadingComponent})],
        "routes": [
          {
            "path": "/~docs",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'README.md' */'/Users/liyao/Desktop/Life/README.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "locale": "en-US",
              "order": null,
              "filePath": "README.md",
              "updatedTime": 1673344756000,
              "slugs": [
                {
                  "depth": 1,
                  "value": "Ant Design Pro",
                  "heading": "ant-design-pro"
                },
                {
                  "depth": 2,
                  "value": "Environment Prepare",
                  "heading": "environment-prepare"
                },
                {
                  "depth": 2,
                  "value": "Provided Scripts",
                  "heading": "provided-scripts"
                },
                {
                  "depth": 3,
                  "value": "Start project",
                  "heading": "start-project"
                },
                {
                  "depth": 3,
                  "value": "Build project",
                  "heading": "build-project"
                },
                {
                  "depth": 3,
                  "value": "Check code style",
                  "heading": "check-code-style"
                },
                {
                  "depth": 3,
                  "value": "Test code",
                  "heading": "test-code"
                },
                {
                  "depth": 2,
                  "value": "More",
                  "heading": "more"
                },
                {
                  "depth": 2,
                  "value": "api",
                  "heading": "api"
                },
                {
                  "depth": 3,
                  "value": "1.添加题目",
                  "heading": "1添加题目"
                },
                {
                  "depth": 3,
                  "value": "2.添加题解",
                  "heading": "2添加题解"
                },
                {
                  "depth": 3,
                  "value": "3.发布评论",
                  "heading": "3发布评论"
                },
                {
                  "depth": 3,
                  "value": "4.OCR",
                  "heading": "4ocr"
                },
                {
                  "depth": 3,
                  "value": "5. get problem description by problemID",
                  "heading": "5-get-problem-description-by-problemid"
                },
                {
                  "depth": 3,
                  "value": "6. get problems published by userID",
                  "heading": "6-get-problems-published-by-userid"
                },
                {
                  "depth": 3,
                  "value": "7. get Unreviewd Problem by class id and user id",
                  "heading": "7-get-unreviewd-problem-by-class-id-and-user-id"
                },
                {
                  "depth": 3,
                  "value": "8. get problem labels by problem ID",
                  "heading": "8-get-problem-labels-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "9. get problem status by problem id",
                  "heading": "9-get-problem-status-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "9. change problem status by problem id",
                  "heading": "9-change-problem-status-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "10. change user name by user id",
                  "heading": "10-change-user-name-by-user-id"
                },
                {
                  "depth": 3,
                  "value": "11. change user phone number by user id",
                  "heading": "11-change-user-phone-number-by-user-id"
                },
                {
                  "depth": 3,
                  "value": "12. change user priority by user id",
                  "heading": "12-change-user-priority-by-user-id"
                },
                {
                  "depth": 3,
                  "value": "13. change user email by user id",
                  "heading": "13-change-user-email-by-user-id"
                },
                {
                  "depth": 3,
                  "value": "14. get user created time by user id",
                  "heading": "14-get-user-created-time-by-user-id"
                },
                {
                  "depth": 3,
                  "value": "15. get user last login time by user id",
                  "heading": "15-get-user-last-login-time-by-user-id"
                },
                {
                  "depth": 3,
                  "value": "16. get problem created at by problem id",
                  "heading": "16-get-problem-created-at-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "17. get problem updated at by problem id",
                  "heading": "17-get-problem-updated-at-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "18. change problem name by problem id",
                  "heading": "18-change-problem-name-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "19. change problem labels by problem id",
                  "heading": "19-change-problem-labels-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "19. change problem description by problem id",
                  "heading": "19-change-problem-description-by-problem-id"
                },
                {
                  "depth": 3,
                  "value": "20. add label",
                  "heading": "20-add-label"
                },
                {
                  "depth": 3,
                  "value": "21. delete label",
                  "heading": "21-delete-label"
                },
                {
                  "depth": 3,
                  "value": "22. delete user",
                  "heading": "22-delete-user"
                },
                {
                  "depth": 3,
                  "value": "23. delete problem",
                  "heading": "23-delete-problem"
                },
                {
                  "depth": 3,
                  "value": "24. delete solution",
                  "heading": "24-delete-solution"
                },
                {
                  "depth": 3,
                  "value": "25. delete comment",
                  "heading": "25-delete-comment"
                },
                {
                  "depth": 3,
                  "value": "25. get class lists of user",
                  "heading": "25-get-class-lists-of-user"
                }
              ],
              "title": "Ant Design Pro"
            },
            "title": "Ant Design Pro"
          },
          {
            "path": "/~docs/components",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'components__index.md' */'/Users/liyao/Desktop/Life/src/components/index.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "filePath": "src/components/index.md",
              "updatedTime": 1672629877000,
              "title": "业务组件",
              "sidemenu": false,
              "slugs": [
                {
                  "depth": 1,
                  "value": "业务组件",
                  "heading": "业务组件"
                },
                {
                  "depth": 2,
                  "value": "Footer 页脚组件",
                  "heading": "footer-页脚组件"
                },
                {
                  "depth": 2,
                  "value": "HeaderDropdown 头部下拉列表",
                  "heading": "headerdropdown-头部下拉列表"
                },
                {
                  "depth": 2,
                  "value": "HeaderSearch 头部搜索框",
                  "heading": "headersearch-头部搜索框"
                },
                {
                  "depth": 3,
                  "value": "API",
                  "heading": "api"
                },
                {
                  "depth": 2,
                  "value": "NoticeIcon 通知工具",
                  "heading": "noticeicon-通知工具"
                },
                {
                  "depth": 3,
                  "value": "NoticeIcon API",
                  "heading": "noticeicon-api"
                },
                {
                  "depth": 3,
                  "value": "NoticeIcon.Tab API",
                  "heading": "noticeicontab-api"
                },
                {
                  "depth": 3,
                  "value": "NoticeIconData",
                  "heading": "noticeicondata"
                },
                {
                  "depth": 2,
                  "value": "RightContent",
                  "heading": "rightcontent"
                }
              ],
              "hasPreviewer": true,
              "group": {
                "path": "/~docs/components",
                "title": "Components"
              }
            },
            "title": "业务组件 - ant-design-pro"
          }
        ],
        "title": "ant-design-pro",
        "component": (props) => props.children
      },
      {
        "path": "/user",
        "layout": false,
        "routes": [
          {
            "name": "login",
            "path": "/user/login",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__Login' */'/Users/liyao/Desktop/Life/src/pages/user/Login'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "register",
            "path": "/user/register",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__register' */'/Users/liyao/Desktop/Life/src/pages/user/register'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/liyao/Desktop/Life/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "name": "控制面板",
        "path": "/control-panel",
        "icon": "appstore",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__course__index' */'/Users/liyao/Desktop/Life/src/pages/course/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/course/solutionDetail",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__course__solutionDetail' */'/Users/liyao/Desktop/Life/src/pages/course/solutionDetail'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "name": "题目",
        "icon": "book",
        "path": "/course/problems",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__course__ProblemPage__index' */'/Users/liyao/Desktop/Life/src/pages/course/ProblemPage/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/course/problems/detail",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__course__ProblemPage__Detail__index' */'/Users/liyao/Desktop/Life/src/pages/course/ProblemPage/Detail/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "name": "account",
        "icon": "user",
        "path": "/account",
        "routes": [
          {
            "name": "个人信息",
            "path": "/account/center",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__account__center' */'/Users/liyao/Desktop/Life/src/pages/account/center'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "个人设置",
            "path": "/account/settings",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__account__settings' */'/Users/liyao/Desktop/Life/src/pages/account/settings'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/liyao/Desktop/Life/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/course-student",
        "name": "课程",
        "icon": "book",
        "access": "canStudent",
        "exact": true
      },
      {
        "path": "/course-teacher",
        "name": "course",
        "icon": "book",
        "access": "canTeacher",
        "exact": true
      },
      {
        "path": "/management-teacher",
        "name": "management",
        "icon": "SmileOutlined",
        "access": "canTeacher",
        "routes": [
          {
            "name": "course1",
            "path": "/management-teacher/course1",
            "exact": true
          },
          {
            "name": "course2",
            "path": "/management-teacher/course2",
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/liyao/Desktop/Life/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/management-admin",
        "name": "management",
        "access": "canAdmin",
        "icon": "CrownOutlined",
        "exact": true
      },
      {
        "path": "/admin",
        "name": "admin",
        "icon": "crown",
        "access": "canAdmin",
        "routes": [
          {
            "path": "/admin/sub-page",
            "name": "sub-page",
            "icon": "smile",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'/Users/liyao/Desktop/Life/src/pages/Welcome'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/liyao/Desktop/Life/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/index.html",
        "redirect": "/lesson",
        "exact": true
      },
      {
        "path": "/",
        "redirect": "/lesson",
        "exact": true
      },
      {
        "name": "审核",
        "icon": "book",
        "path": "/review",
        "access": "canTeacher",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__ProblemReview__index' */'/Users/liyao/Desktop/Life/src/pages/ProblemReview/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/reviewSolutionDetail",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__ReviewSolutionDetail__index' */'/Users/liyao/Desktop/Life/src/pages/ReviewSolutionDetail/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "name": "Test",
        "path": "/test",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Test' */'/Users/liyao/Desktop/Life/src/pages/Test'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'/Users/liyao/Desktop/Life/src/pages/404'), loading: LoadingComponent}),
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
