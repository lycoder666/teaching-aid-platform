from django.apps import AppConfig


class AidPlatformConfig(AppConfig):
    name = 'aid_platform'
