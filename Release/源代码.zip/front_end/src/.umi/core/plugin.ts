// @ts-nocheck
import { Plugin } from '/Users/liyao/Desktop/Life/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','getInitialState','initialStateConfig','locale','layout','layoutActionRef','request',],
});

export { plugin };
