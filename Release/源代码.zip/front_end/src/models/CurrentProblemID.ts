import { useState } from 'react';

export default () => {
  const [currentProblemID, setCurrentProblemID] = useState(1);
  return { currentProblemID, setCurrentProblemID };
};
