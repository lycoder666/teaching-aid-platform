// @ts-nocheck

import AppstoreOutlined from '@ant-design/icons/AppstoreOutlined';
import BookOutlined from '@ant-design/icons/BookOutlined';
import UserOutlined from '@ant-design/icons/UserOutlined';
import SmileOutlined from '@ant-design/icons/SmileOutlined';
import CrownOutlined from '@ant-design/icons/CrownOutlined'

export default {
  AppstoreOutlined,
BookOutlined,
UserOutlined,
SmileOutlined,
CrownOutlined
}
    