import React, { useEffect, useState } from 'react';
import styles from './index.less';
import Icon, {
  LikeFilled,
  LikeOutlined,
  MessageOutlined,
  StarFilled,
  StarOutlined,
  StarTwoTone,
} from '@ant-design/icons';
import { Avatar, List, Space, Tag, theme } from 'antd';
import { FC } from 'react';
import { ProCard } from '@ant-design/pro-components';
import { useModel } from '@@/plugin-model/useModel';
import SolutionDetail from '@/pages/course/solutionDetail';
import { toNumber } from 'lodash';
import { request } from 'umi';
import { useRequest } from '@umijs/hooks';

type IProps = {
  problemId: number;
};

// const data = Array.from({length: 23}).map((_, i) => ({
//   solutionId: 1,
//   href: 'https://ant.design',
//   title: `ant design part ${i}`,
//   avatar: 'https://joeschmoe.io/api/v1/random',
//   description:
//     'Ant Design, a design language for background applications, is refined by Ant UED Team.',
//   content:
//     'We supply a series of design principles, practical patterns and high quality design resources (Sketch and Axure), ' +
//     'to help people create their product prototypes beautifully and efficiently.',
// }));

// const chageInfo = (icon: React.FC, soulutionId: number) => {
//     if (icon === LikeOutlined) {
//
//     }else {
//
//     }
// };

//点赞组件
const Like = ({ item }: { item: API.SolutionDetail }) => {
  // const { initialState } = useModel('@@initialState');
  // //获取数据
  // const getLikes = async (token: string, solutionId: number) => {
  //   const data = await request(`/api/likes/${solutionId}`, {
  //     method: 'GET',
  //     headers: {
  //       Authorization: `${token}`,
  //       'Content-Type': 'application/json',
  //     },
  //   });
  //   return data;
  // };
  // const token = initialState.currentUser.token;
  // console.log('token in Likes', token);

  // const { data, error, loading } = useRequest(() => {
  //   return getLikes(token, item.id);
  // });

  const getLikes = async (token: string, solutionId: number) => {
    const data = await request(`/api/likes/${solutionId}`, {
      method: 'GET',
      headers: {
        Authorization: `${token}`,
      },
    });
    return data;
  };
  const { initialState } = useModel('@@initialState');
  const token = initialState.currentUser.token;
  const { data, error, loading } = useRequest(() => {
    return getLikes(token, item.id);
  });

  const modifyLikes = async (token: string, solutionId: number, is_liked: boolean) => {
    const modifyLikesData = await request(`/api/likes/${solutionId}`, {
      method: 'post',
      headers: {
        Authorization: `${token}`,
        'Content-Type': 'application/json',
      },
      data: {
        is_liked: is_liked,
      },
    });
    return modifyLikesData;
  };

  const [count, setCount] = useState(-1);
  const [isLiked, setIsLiked] = useState(false);
  if (loading) {
    return <div>loading...</div>;
  }
  if (error) {
    return <div>error</div>;
  }
  let likes_count = data.likes;
  if (count === -1) {
    setCount(likes_count);
    setIsLiked(data.is_liked);
  }
  const ChangeInfo = async () => {
    //修改点赞信息
    setIsLiked(!isLiked);
    /**
     * To do: 向后端发送请求修改点赞信息
     */
    useRequest(() => {
      modifyLikes(initialState.currentUser.token, item.id, isLiked);
    });

    setCount(isLiked ? count - 1 : count + 1);
  };

  return (
    <Space
      onClick={() => {
        ChangeInfo();
      }}
    >
      {isLiked ? <LikeFilled /> : <LikeOutlined />}
      {likes_count}
    </Space>
  );
};

//收藏组件
const Star = ({ item }: { item: API.SolutionDetail }) => {
  const { initialState } = useModel('@@initialState');

  //获取数据
  const getStars = async (token: string, solutionId: number) => {
    const data = await request(`/api/stars/${solutionId}/`, {
      method: 'get',
      headers: {
        Authorization: `${token}`,
        'Content-Type': 'application/json',
      },
    });
    return data;
  };

  const [count, setCount] = useState(-1);
  const [isStared, setIsStared] = useState(false);
  const { data, error, loading } = useRequest(() => {
    return getStars(initialState.currentUser.token, item.id);
  });
  if (loading) {
    return <div>loading...</div>;
  }
  if (error) {
    return <div>error</div>;
  }
  let stars_count = data.stars;
  if (count === -1) {
    setCount(stars_count);
    setIsStared(data.is_stared);
  }
  const modifyStars = async (token: string, solutionId: number, is_stared: boolean) => {
    const dataStars = await request(`/api/stars/${solutionId}`, {
      method: 'post',
      headers: {
        Authorization: `${token}`,
        'Content-Type': 'application/json',
      },
      data: {
        is_stared: is_stared,
      },
    });
    return dataStars;
  };
  const ChangeInfo = async () => {
    //修改点赞信息
    setIsStared(!isStared);
    /**
     * To do: 向后端发送请求修改点赞信息
     */
    useRequest(() => {
      modifyStars(initialState.currentUser.token, item.id, isStared);
    });

    setCount(isStared ? count - 1 : count + 1);
  };

  return (
    <Space
      onClick={() => {
        ChangeInfo();
      }}
    >
      {isStared ? <StarFilled /> : <StarOutlined />}
      {count}
    </Space>
  );
};

//评论组件
const Message = ({ item }: { item: API.SolutionDetail }) => {
  const getComments = async (solutionId: number) => {
    const dataComments = await request(`/api/getSolutionComments/${solutionId}/`, {
      method: 'get',
    });
    return dataComments;
  };
  const { data, error, loading } = useRequest(() => {
    return getComments(item.id);
  });
  if (loading) {
    return <div>Loading...</div>;
  }
  if (error) {
    return <div>error</div>;
  }
  const count = data.length;
  return (
    <Space>
      <MessageOutlined>{count}</MessageOutlined>
    </Space>
  );
};
/**
 * 题解列表组件
 * @constructor
 */

const Solutions: FC<IProps> = (props: IProps) => {
  const { currentProblemID } = useModel('CurrentProblemID');
  console.log('solutions currentProblemID', currentProblemID);

  const getProblemSolutions = async (id: number) => {
    const data = await request(`/api/getProblemSolutions/${id}`, {
      method: 'get',
    });
    return data;
  };
  const [isCliked, setIsClicked] = useState(false);
  //点击详情的题解id
  const [clickId, setClickId] = useState<number>(undefined);
  const { initialState } = useModel('@@initialState');
  //根据题目id获取对应的题解

  const { data, error, loading } = useRequest(() => {
    return getProblemSolutions(currentProblemID);
  });
  if (loading) {
    return <div>loading</div>;
  }
  if (error) {
    return <div>error</div>;
  }
  console.log(data);

  //是否点击详情

  const data1 = data.solution_list || [];

  /**
   * 点击列表项设置信息
   * @param id
   */
  const click = (id: number) => {
    setIsClicked(true);
    setClickId(id);
  };

  // @ts-ignore
  return (
    <div>
      <ProCard split={'vertical'} style={{ borderRadius: 5 }}>
        <ProCard
          colSpan={'45%'}
          style={{ height: document.body.clientHeight - 160, overflow: 'auto' }}
        >
          <List
            itemLayout="vertical"
            size="large"
            pagination={{
              onChange: (page) => {
                console.log(page);
              },
              pageSize: 7,
              hideOnSinglePage: true,
              showLessItems: true,
            }}
            dataSource={data1.sort((a, b) => b.isChecked - a.isChecked)}
            renderItem={(item) => (
              <List.Item
                onClick={() => {
                  click(item.id);
                }}
                key={item.solutionName}
                actions={[<Star item={item} />, <Like item={item} />, <Message item={item} />]}
              >
                <List.Item.Meta
                  //https://joeschmoe.io/api/v1/random
                  avatar={
                    <Avatar
                      src={
                        'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png'
                      }
                    />
                  }
                  title={item.isChecked ? <Tag color="red">{'已审核'}</Tag> : ''}
                  description={initialState.currentUser.username}
                />
                <p className={styles.item}>{item.solutionName}</p>
              </List.Item>
            )}
          />
        </ProCard>
        <ProCard>{isCliked && <SolutionDetail solutionId={clickId} />}</ProCard>
      </ProCard>
    </div>
  );
};

export default Solutions;
