function routePlanning(ent:dict){
    var ent2 = ent

    for (let key in ent)
    {
        latitude1 = ent[latitude]
        longtitude = ent[longtitude]

    }
}
