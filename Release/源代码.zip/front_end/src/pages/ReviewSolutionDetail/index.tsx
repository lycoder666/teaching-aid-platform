import { FC } from 'react';
import ReactMarkdown from 'react-markdown';
import { Alert, Avatar, Button, Form, Input, List, Select, message } from 'antd';
import gfm from 'remark-gfm';
import 'katex/dist/katex.min.css';
import rehypeKatex from 'rehype-katex';
import remarkMath from 'remark-math';
import { ProCard } from '@ant-design/pro-components';
import { useLocation, useModel } from 'umi';
import { request } from 'umi';
import { useRequest } from '@umijs/hooks';
import { useForm } from 'antd/es/form/Form';
import { values } from 'lodash';
import { useState } from 'react';
import CurrentReviewSolutionID from '@/models/CurrentReviewSolutionID';

// const data = Array.from({length: 23}).map((_, i) => ({
//   href: 'https://ant.design',
//   title: `ant design part ${i}`,
//   avatar: 'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png',
//   description:
//     'Ant Design, a design language for background applications, is refined by Ant UED Team.',
//   content:
//     '这篇题解从思路梳理到用词推敲，是我最满意的一篇。因为它收到一个赞我就再读一遍，再改一改，改了有几十遍……希望你读的时候，它是很流畅的样子。',
// }));

interface IProps {
  solutionId: number;
}

/**
 * 题解详情组件
 * @param props
 * @constructor
 */
const SolutionDetail: FC<IProps> = (props) => {
  const { reviewSolutionID, setReviewSolutionID } = useModel('CurrentReviewSolutionID');

  const getSolutionDescription = async (solutionId: number) => {
    const sol_des_data = await request(`/api/getSolutionDescriptionBySolutionID/${solutionId}`, {
      method: 'GET',
    });
    return sol_des_data;
  };
  const {
    data: sol_des,
    error: sol_des_error,
    loading: sol_des_loading,
  } = useRequest(() => {
    return getSolutionDescription(reviewSolutionID);
  });
  console.log('sol_des', sol_des);
  if (sol_des_loading) {
    return <div>loading...</div>;
  }
  if (sol_des_error) {
    return <div>error</div>;
  }

  const clickFun = async (solutionId: number) => {
    const review_pass_data = await request(`/api/changeSolutionStatus/`, {
      method: 'POST',
      data: {
        solutionID: solutionId,
      },
    });
    if (review_pass_data) {
      message.success('审核通过');
    }
  };

  return (
    <div style={{ height: document.body.clientHeight - 160, overflow: 'auto' }}>
      <div>
        <List.Item.Meta
          avatar={
            <Avatar
              src={'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png'}
            />
          }
          title={<p>滑动窗口</p>}
          description={'user'}
        />
      </div>
      <div>
        <ProCard type={'inner'} style={{ background: '#F7F7F7', borderRadius: 5 }} bordered>
          {/*题解内容展示*/}
          <ReactMarkdown remarkPlugins={[gfm, remarkMath]} rehypePlugins={[rehypeKatex]}>
            {sol_des.solutionDescription}
          </ReactMarkdown>
        </ProCard>
      </div>
      <Button
        type="primary"
        onClick={async () => {
          await clickFun(reviewSolutionID);
        }}
      >
        审核通过
      </Button>
    </div>
  );
};

export default SolutionDetail;
