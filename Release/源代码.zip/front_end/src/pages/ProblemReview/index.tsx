import { Button, Spin, Table, Typography } from 'antd';
import { ProTable } from '@ant-design/pro-components';
import { Link } from 'umi';
import { request } from 'umi';
import { useRequest } from '@umijs/hooks';
import { history } from 'umi';
const { Text } = Typography;
import { useModel } from 'umi';

type SolutionItem = {
  id: number;
  solutionName: string;
  createdAt: number;
};

const ReviewSolution: React.FC = () => {
  const { reviewSolutionID, setReviewSolutionID } = useModel('CurrentReviewSolutionID');
  const solutionColumns = [
    {
      title: 'ID',
      index: 'id',
      search: true,
      tip: 'ID是唯一的',
      render: (_: any, record: SolutionItem) => {
        return <Text>{record.id}</Text>;
      },
    },
    {
      title: '名称',
      index: 'solutionName',
      search: true,
      copyable: true,
      elipsis: true,
      tip: '名称过长会自动收缩',
      formItemProps: {
        rules: [
          {
            required: true,
            message: '名称为必填项',
          },
        ],
      },
      render: (_: any, record: SolutionItem) => {
        return <Text>{record.solutionName}</Text>;
      },
    },
    {
      title: '创建时间',
      index: 'createdAt',
      sorter: true,
      valueType: 'dateTime',
      render: (_: any, record: SolutionItem) => {
        return <span>{new Date(record.createdAt).toLocaleDateString()}</span>;
      },
    },
    {
      title: '操作',
      render: (_: any, record: SolutionItem) => {
        return (
          <Link
            to={{ pathname: '/reviewSolutionDetail' }}
            onClick={() => {
              setReviewSolutionID(record.id);
            }}
          >
            查看/审核
          </Link>
        );
      },
    },
  ];
  const getUnreviewedSolutions = async () => {
    const res = await request('/api/getUnreviewedSolution/');
    return res;
  };
  const { data, error, loading } = useRequest(() => {
    return getUnreviewedSolutions();
  });
  if (error) {
    return <div>Error info</div>;
  }
  if (loading) {
    return <div>Loading...</div>;
  }

  console.log('unreviewd data', data);
  console.log('type data', typeof []);
  const dataList = data.solution_list;
  console.log('dataList', dataList);

  return (
    <>
      <Table
        columns={solutionColumns}
        rowKey="id"
        search={{
          labelWidth: 'auto',
        }}
        toolBarRender={() => []}
        dataSource={dataList}
      />
    </>
  );
};

const Loading = () => {
  return (
    <div className="loading">
      <Spin size="large" />
    </div>
  );
};

export default () => {
  return <ReviewSolution />;
};
