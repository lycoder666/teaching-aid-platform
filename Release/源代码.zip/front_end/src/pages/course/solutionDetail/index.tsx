import { FC } from 'react';
import ReactMarkdown from 'react-markdown';
import { Avatar, Button, Form, Input, List, Select } from 'antd';
import gfm from 'remark-gfm';
import 'katex/dist/katex.min.css';
import rehypeKatex from 'rehype-katex';
import remarkMath from 'remark-math';
import { ProCard } from '@ant-design/pro-components';
import { useLocation, useModel } from 'umi';
import { request } from 'umi';
import { useRequest } from '@umijs/hooks';
import { useForm } from 'antd/es/form/Form';
import { useState } from 'react';

// const data = Array.from({length: 23}).map((_, i) => ({
//   href: 'https://ant.design',
//   title: `ant design part ${i}`,
//   avatar: 'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png',
//   description:
//     'Ant Design, a design language for background applications, is refined by Ant UED Team.',
//   content:
//     '这篇题解从思路梳理到用词推敲，是我最满意的一篇。因为它收到一个赞我就再读一遍，再改一改，改了有几十遍……希望你读的时候，它是很流畅的样子。',
// }));

interface IProps {
  solutionId: number;
}

/**
 * 题解详情组件
 * @param props
 * @constructor
 */
const SolutionDetail: FC<IProps> = (props) => {
  const [form] = useForm();
  const location = useLocation();
  const { initialState } = useModel('@@initialState');
  const token = initialState?.currentUser?.token;
  const sid = location?.state?.solutionId;
  const solutionId = sid ? sid : props.solutionId;
  const addComment = async (solutionId: number, content: string, token: string) => {
    const data = await request('/api/addComment/', {
      method: 'POST',
      headers: {
        Authorization: `${token}`,
      },
      data: {
        solutionId: solutionId,
        content: content,
      },
    });
    return data;
  };

  const getSolutionDescription = async (solutionId: number) => {
    const sol_des_data = await request(`/api/getSolutionDescriptionBySolutionID/${solutionId}`, {
      method: 'GET',
    });
    return sol_des_data;
  };
  const {
    data: sol_des,
    error: sol_des_error,
    loading: sol_des_loading,
  } = useRequest(() => {
    return getSolutionDescription(solutionId);
  });

  const getComments = async (solutionID: number) => {
    const dataComments = await request(`/api/getSolutionComments/${solutionID}/`, {
      method: 'get',
    });
    return dataComments;
  };
  const {
    data: sol_comments,
    error,
    loading,
  } = useRequest(() => {
    return getComments(solutionId);
  });
  if (loading) {
    return <div>Loading...</div>;
  }
  if (error) {
    return <div>error</div>;
  }

  if (sol_des_error) {
    return <div>Error info</div>;
  }
  if (sol_des_loading) {
    return <div>Loading...</div>;
  }
  const onFinish = async (values: any) => {
    // let hasChanged = false;
    console.log('succes commit', values);
    addComment(solutionId, values.content, token);
    form.resetFields();
    // const newComments = await getComments(solutionId);
    // if (hasChanged === false) {
    //   changeComments(newComments);
    //   hasChanged = true;
    // }
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo);
  };
  // const md = `# 题意解释：
  // - 一共有 n 门课要上，编号为 0 ~ n-1。\n
  // - 先决条件[1, 0]，意思是必须先上课 0，才能上课 1。\n
  // - 给你 n 、和一个先决条件表，请你判断能否完成所有课程。\n
  // `

  return (
    <div style={{ height: document.body.clientHeight - 160, overflow: 'auto' }}>
      <div>
        <List.Item.Meta
          avatar={
            <Avatar
              src={'https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png'}
            />
          }
          title={<p>滑动窗口</p>}
          description={'user'}
        ></List.Item.Meta>
      </div>
      <div>
        <ProCard type={'inner'} style={{ background: '#F7F7F7', borderRadius: 5 }} bordered>
          {/*题解内容展示*/}
          <ReactMarkdown remarkPlugins={[gfm, remarkMath]} rehypePlugins={[rehypeKatex]}>
            {sol_des.solutionDescription}
          </ReactMarkdown>
        </ProCard>

        <br />
        <br />
        <br />
        {/*评论展示*/}
        <List
          itemLayout="vertical"
          size="large"
          pagination={{
            onChange: (page) => {
              console.log(page);
            },
            pageSize: 7,
          }}
          dataSource={sol_comments}
          renderItem={(item) => (
            <List.Item key={item.id}>
              <List.Item.Meta
                avatar={
                  <Avatar src="https://gw.alipayobjects.com/zos/antfincdn/XAosXuNZyF/BiazfanxmamNRoxxVxka.png" />
                }
                // title={<a href={item.href}>{item.title}</a>}
              />
              {item.commentContent}
            </List.Item>
          )}
        />

        <Form
          name="addComment"
          wrapperCol={{ span: 16 }}
          initialValues={{ remember: true }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
          form={form}
        >
          <Form.Item
            label="内容"
            name="content"
            // rules={[{ required: true, message: '请输入题目描述' }]}
            wrapperCol={{ span: 16, offset: 0 }}
          >
            <Input.TextArea style={{ height: 300 }} />
          </Form.Item>
          <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
            <Button type="primary" htmlType="submit">
              发布
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default SolutionDetail;
