import { useModel } from 'umi';
import { request } from 'umi';
import { useRequest } from '@umijs/hooks';
export default () => {
  const getLikes = async (token: string, solutionId: number) => {
    const data = await request(`/api/likes/${solutionId}`, {
      method: 'GET',
      headers: {
        Authorization: `${token}`,
      },
    });
    return data;
  };
  const { initialState } = useModel('@@initialState');
  const token = initialState.currentUser.token;
  const { data, error, loading } = useRequest(() => {
    return getLikes(token, 3);
  });
  if (error || loading) {
    return <div>loading...</div>;
  }

  console.log(data);

  return (
    <>
      <div>{JSON.stringify(data)}</div>
    </>
  );
};
