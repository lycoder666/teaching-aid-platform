// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as checkUsername from './checkUsername';
import * as getCourseDetail from './getCourseDetail';
import * as getCourseLabels from './getCourseLabels';
import * as getCourseProblems from './getCourseProblems';
import * as getLabelProblems from './getLabelProblems';
import * as getProblemSolutions from './getProblemSolutions';
import * as getUserCourses from './getUserCourses';
import * as init from './init';
import * as login from './login';
import * as regist from './regist';
export default {
  checkUsername,
  getCourseDetail,
  getCourseLabels,
  getCourseProblems,
  getLabelProblems,
  getProblemSolutions,
  getUserCourses,
  init,
  login,
  regist,
};
