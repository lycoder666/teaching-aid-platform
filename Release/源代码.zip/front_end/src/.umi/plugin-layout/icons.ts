// @ts-nocheck

  import AppstoreOutlined from '@ant-design/icons/es/icons/AppstoreOutlined';
import BookOutlined from '@ant-design/icons/es/icons/BookOutlined';
import UserOutlined from '@ant-design/icons/es/icons/UserOutlined';
import SmileOutlined from '@ant-design/icons/es/icons/SmileOutlined';
import CrownOutlined from '@ant-design/icons/es/icons/CrownOutlined'
  export default {
    AppstoreOutlined,
BookOutlined,
UserOutlined,
SmileOutlined,
CrownOutlined
  }