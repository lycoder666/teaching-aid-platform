import { useState } from 'react';

export default () => {
  const [currentCourseID, setCurrentCourseID] = useState(0);
  return { currentCourseID, setCurrentCourseID };
};
