import Classes from './components/ClassChoosePanel/index';

const CoursePage: React.FC = () => {
  return (
    <>
      <Classes />
    </>
  );
};

export default CoursePage;
